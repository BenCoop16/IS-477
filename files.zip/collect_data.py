"""
collect_data.py
Collects Reddit posts from r/Bitcoin via the Arctic Shift API
and downloads weekly BTC-USD price data from Yahoo Finance.

Outputs:
    reddit_bitcoin_raw.csv
    crypto_prices_raw.csv
"""

import requests
import pandas as pd
import time
import yfinance as yf
from datetime import datetime, timedelta

# ── Reddit collection ─────────────────────────────────────────────────────────

all_posts = []

start_date = datetime(2024, 1, 1)
end_date   = datetime(2026, 1, 1)
posts_per_week = 30

current = start_date
while current < end_date:
    next_week = current + timedelta(weeks=1)

    params = {
        "subreddit": "Bitcoin",
        "after":     current.strftime("%Y-%m-%d"),
        "before":    next_week.strftime("%Y-%m-%d"),
        "limit":     posts_per_week,
        "sort":      "asc"
    }

    response = requests.get(
        "https://arctic-shift.photon-reddit.com/api/posts/search",
        params=params
    )
    batch = response.json().get('data') or []

    if batch:
        all_posts.extend(batch)

    print(f"Week of {current.date()}: {len(batch)} posts, total: {len(all_posts)}")
    current = next_week
    time.sleep(0.5)

df_bitcoin = pd.DataFrame(all_posts)[
    ['id', 'title', 'selftext', 'score', 'upvote_ratio', 'num_comments', 'created_utc', 'subreddit']
]
df_bitcoin['timestamp'] = pd.to_datetime(df_bitcoin['created_utc'], unit='s')
df_bitcoin.to_csv('reddit_bitcoin_raw.csv', index=False)
print(f"\nReddit data saved: {df_bitcoin.shape[0]} rows → reddit_bitcoin_raw.csv")

# ── Bitcoin price download ────────────────────────────────────────────────────

df_price = yf.download("BTC-USD", start="2024-01-01", end="2026-01-01", interval="1wk")
df_price_clean = df_price.copy()
df_price_clean = df_price_clean.reset_index()
df_price_clean.columns = [
    c[0].lower() if isinstance(c, tuple) else c.lower()
    for c in df_price_clean.columns
]
df_price_clean.rename(columns={'price': 'date'}, inplace=True)
df_price_clean['date'] = pd.to_datetime(df_price_clean['date'])

# Normalize to Monday so it lines up with week_start in the Reddit data
df_price_clean['date'] = (
    df_price_clean['date']
    - pd.to_timedelta(df_price_clean['date'].dt.dayofweek, unit='D')
)

df_price_clean['price_change']     = df_price_clean['close'] - df_price_clean['open']
df_price_clean['price_pct_change'] = (
    df_price_clean['price_change'] / df_price_clean['open']
) * 100

df_price_clean.to_csv('crypto_prices_raw.csv', index=False)
print(f"Price data saved: {df_price_clean.shape[0]} rows → crypto_prices_raw.csv")
