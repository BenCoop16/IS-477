"""
clean_data.py
Cleans raw Reddit data, scores sentiment with VADER,
and aggregates both datasets to weekly level.

Inputs:
    reddit_bitcoin_raw.csv
    crypto_prices_raw.csv

Outputs:
    reddit_bitcoin_clean.csv
    crypto_prices_clean.csv
"""

import pandas as pd
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# ── Load raw data ─────────────────────────────────────────────────────────────

df_bitcoin  = pd.read_csv('reddit_bitcoin_raw.csv')
df_price    = pd.read_csv('crypto_prices_raw.csv', parse_dates=['date'])

print(f"Raw Reddit posts: {df_bitcoin.shape[0]}")
print(f"Raw price rows:   {df_price.shape[0]}")

# ── Reddit quality check ──────────────────────────────────────────────────────

print("\nDuplicates:",        df_bitcoin.duplicated(subset='id').sum())
print("Missing values:\n",   df_bitcoin.isnull().sum())
print("Removed posts:",      (df_bitcoin['selftext'] == '[removed]').sum())
print("Deleted posts:",      (df_bitcoin['selftext'] == '[deleted]').sum())

# ── Reddit cleaning ───────────────────────────────────────────────────────────

df_bitcoin_clean = df_bitcoin[df_bitcoin['selftext'] != '[removed]']
df_bitcoin_clean = df_bitcoin_clean[df_bitcoin_clean['selftext'] != '[deleted]']
df_bitcoin_clean = df_bitcoin_clean.drop_duplicates(subset='id')
df_bitcoin_clean = df_bitcoin_clean.reset_index(drop=True)
print(f"\nAfter cleaning: {df_bitcoin_clean.shape[0]} posts")

# Assign week_start (Monday anchor)
df_bitcoin_clean['timestamp'] = pd.to_datetime(df_bitcoin_clean['created_utc'], unit='s')
df_bitcoin_clean['week_start'] = (
    df_bitcoin_clean['timestamp']
    - pd.to_timedelta(df_bitcoin_clean['timestamp'].dt.dayofweek, unit='D')
).dt.normalize()

# ── VADER sentiment scoring ───────────────────────────────────────────────────

analyzer = SentimentIntensityAnalyzer()
df_bitcoin_clean['sentiment'] = df_bitcoin_clean['title'].apply(
    lambda x: analyzer.polarity_scores(x)['compound']
)

def label_sentiment(score):
    if score >= 0.05:
        return 'positive'
    elif score <= -0.05:
        return 'negative'
    else:
        return 'neutral'

df_bitcoin_clean['sentiment_label'] = df_bitcoin_clean['sentiment'].apply(label_sentiment)
print("\nSentiment distribution:")
print(df_bitcoin_clean['sentiment_label'].value_counts())

# ── Save clean Reddit data ────────────────────────────────────────────────────

df_bitcoin_clean.to_csv('reddit_bitcoin_clean.csv', index=False)
print("\nSaved → reddit_bitcoin_clean.csv")

# ── Price quality check ───────────────────────────────────────────────────────

print("\nPrice duplicates:", df_price.duplicated().sum())
print("Price missing:\n",  df_price.isnull().sum())

df_price.to_csv('crypto_prices_clean.csv', index=False)
print("Saved → crypto_prices_clean.csv")
