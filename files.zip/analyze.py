"""
analyze.py
Generates all visualizations and runs hypothesis tests
for both research questions.

Inputs:
    weekly_merged.csv
    reddit_bitcoin_clean.csv  (for post-level sentiment chart)
    crypto_prices_clean.csv   (for price-only chart)

Outputs:
    fig1_btc_price.png
    fig2_sentiment_over_time.png
    fig3_price_vs_sentiment.png
    fig4_scatter_sentiment_vs_price.png
    results.txt
"""

import pandas as pd
import matplotlib
matplotlib.use('Agg')  # non-interactive backend for script use
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from scipy.stats import linregress

# ── Load data ─────────────────────────────────────────────────────────────────

df_merged        = pd.read_csv('weekly_merged.csv',        parse_dates=['date'])
df_bitcoin_clean = pd.read_csv('reddit_bitcoin_clean.csv', parse_dates=['timestamp'])
df_price_clean   = pd.read_csv('crypto_prices_clean.csv',  parse_dates=['date'])

# ── Fig 1: BTC price over time ────────────────────────────────────────────────

fig, ax = plt.subplots(figsize=(14, 5))
ax.plot(df_price_clean['date'], df_price_clean['close'], color='#F7931A', linewidth=1.5)
ax.set_title('Bitcoin (BTC-USD) Closing Price: Jan 2024 – Jan 2026', fontsize=14, fontweight='bold')
ax.set_xlabel('Date')
ax.set_ylabel('Price (USD)')
ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig('fig1_btc_price.png', dpi=150)
plt.close()
print("Saved → fig1_btc_price.png")

# ── Fig 2: Sentiment over time ────────────────────────────────────────────────

fig, ax = plt.subplots(figsize=(14, 5))
ax.plot(df_bitcoin_clean['timestamp'], df_bitcoin_clean['sentiment'],
        color='steelblue', linewidth=0.8, alpha=0.4, label='Post Sentiment')
rolling = df_bitcoin_clean.set_index('timestamp')['sentiment'].rolling('7D').mean()
ax.plot(rolling.index, rolling.values, color='navy', linewidth=2, label='7-Day Rolling Avg')
ax.axhline(0, color='gray', linestyle='--', linewidth=0.8)
ax.set_title('Reddit Post Sentiment (r/Bitcoin): Jan 2024 – Jan 2026', fontsize=14, fontweight='bold')
ax.set_xlabel('Date')
ax.set_ylabel('VADER Compound Score')
ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
ax.legend()
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig('fig2_sentiment_over_time.png', dpi=150)
plt.close()
print("Saved → fig2_sentiment_over_time.png")

# ── Fig 3: Dual-axis price vs sentiment ───────────────────────────────────────

fig, ax1 = plt.subplots(figsize=(14, 6))
ax1.plot(df_price_clean['date'], df_price_clean['close'], color='#F7931A', linewidth=1.5, label='BTC Price')
ax1.set_xlabel('Date')
ax1.set_ylabel('BTC Closing Price (USD)', color='#F7931A')
ax1.tick_params(axis='y', labelcolor='#F7931A')

ax2 = ax1.twinx()
ax2.plot(df_merged['date'], df_merged['avg_sentiment'], color='steelblue', linewidth=1.5, alpha=0.8, label='Weekly Avg Sentiment')
ax2.axhline(0, color='gray', linestyle='--', linewidth=0.6)
ax2.set_ylabel('Avg Weekly Sentiment Score', color='steelblue')
ax2.tick_params(axis='y', labelcolor='steelblue')

ax1.set_title('Bitcoin Price vs. Weekly Reddit Sentiment Over Time', fontsize=14, fontweight='bold')
ax1.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
ax1.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left')
plt.xticks(rotation=30)
plt.tight_layout()
plt.savefig('fig3_price_vs_sentiment.png', dpi=150)
plt.close()
print("Saved → fig3_price_vs_sentiment.png")

# ── Fig 4: Scatter sentiment vs next-week price change ────────────────────────

subset = df_merged[['avg_sentiment', 'price_pct_change']].copy()
subset['next_week_pct'] = subset['price_pct_change'].shift(-1)
subset = subset.dropna()

fig, ax = plt.subplots(figsize=(8, 6))
ax.scatter(subset['avg_sentiment'], subset['next_week_pct'],
           alpha=0.4, edgecolors='k', linewidths=0.3, color='steelblue')
ax.axhline(0, color='gray', linestyle='--', linewidth=0.7)
ax.axvline(0, color='gray', linestyle='--', linewidth=0.7)
ax.set_title('Weekly Reddit Sentiment vs. BTC Price Change (Following Week)', fontsize=13, fontweight='bold')
ax.set_xlabel('Average Weekly Sentiment Score (VADER)')
ax.set_ylabel('BTC Price % Change (1 Week Later)')
plt.tight_layout()
plt.savefig('fig4_scatter_sentiment_vs_price.png', dpi=150)
plt.close()
print("Saved → fig4_scatter_sentiment_vs_price.png")

# ── Hypothesis testing ────────────────────────────────────────────────────────

df_merged['next_week_pct'] = df_merged['price_pct_change'].shift(-1)
rq1_data = df_merged[['avg_sentiment', 'next_week_pct']].dropna()

slope, intercept, r, p, se = linregress(rq1_data['avg_sentiment'], rq1_data['next_week_pct'])

q75 = df_merged['avg_score'].quantile(0.75)
high_upvote = df_merged[df_merged['avg_score'] > q75][['avg_sentiment', 'next_week_pct']].dropna()
slope, intercept, r_high, p_high, se = linregress(high_upvote['avg_sentiment'], high_upvote['next_week_pct'])

low_upvote = df_merged[df_merged['avg_score'] <= q75][['avg_sentiment', 'next_week_pct']].dropna()
slope, intercept, r_low, p_low, se = linregress(low_upvote['avg_sentiment'], low_upvote['next_week_pct'])

results = f"""
RQ1: Sentiment vs. Next Week Price Change
  r = {r:.4f}, p = {p:.4f}

RQ2: High vs. Low Upvote Posts (75th pct = {q75:.0f})
  High upvote posts: r = {r_high:.4f}, p = {p_high:.4f}
  Low upvote posts:  r = {r_low:.4f}, p = {p_low:.4f}
"""

print(results)
with open('results.txt', 'w') as f:
    f.write(results)
print("Saved → results.txt")
