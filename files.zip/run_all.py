"""
run_all.py
Simple alternative to Snakemake — runs the full pipeline
sequentially in one go.

Usage:
    python run_all.py
"""

import subprocess
import sys

steps = [
    ("Collecting data",     "collect_data.py"),
    ("Cleaning data",       "clean_data.py"),
    ("Merging datasets",    "merge_data.py"),
    ("Running analysis",    "analyze.py"),
]

for label, script in steps:
    print(f"\n{'='*50}")
    print(f"  {label}...")
    print(f"{'='*50}")
    result = subprocess.run([sys.executable, script], check=True)

print("\n✓ Pipeline complete. Check results.txt and fig1–fig4 PNGs for output.")
