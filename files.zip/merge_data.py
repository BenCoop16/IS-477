"""
merge_data.py
Aggregates cleaned Reddit posts to weekly sentiment scores
and merges with weekly Bitcoin price data.

Inputs:
    reddit_bitcoin_clean.csv
    crypto_prices_clean.csv

Outputs:
    weekly_merged.csv
"""

import pandas as pd

# ── Load clean data ───────────────────────────────────────────────────────────

df_bitcoin_clean = pd.read_csv('reddit_bitcoin_clean.csv', parse_dates=['timestamp', 'week_start'])
df_price_clean   = pd.read_csv('crypto_prices_clean.csv',  parse_dates=['date'])

print(f"Clean Reddit posts: {df_bitcoin_clean.shape[0]}")
print(f"Clean price rows:   {df_price_clean.shape[0]}")

# ── Weekly Reddit aggregation ─────────────────────────────────────────────────

df_weekly_reddit = df_bitcoin_clean.groupby('week_start').agg(
    post_count       = ('id',              'count'),
    avg_score        = ('score',           'mean'),
    avg_upvote_ratio = ('upvote_ratio',    'mean'),
    avg_comments     = ('num_comments',    'mean'),
    avg_sentiment    = ('sentiment',       'mean'),
    positive_ratio   = ('sentiment_label', lambda x: (x == 'positive').sum() / len(x)),
    negative_ratio   = ('sentiment_label', lambda x: (x == 'negative').sum() / len(x)),
).reset_index()
df_weekly_reddit.rename(columns={'week_start': 'date'}, inplace=True)

print(f"\nWeekly Reddit rows: {df_weekly_reddit.shape[0]}")

# ── Merge ─────────────────────────────────────────────────────────────────────

df_merged = pd.merge(df_weekly_reddit, df_price_clean, on='date', how='inner')
print(f"Merged shape: {df_merged.shape}")
print(df_merged.head())

df_merged.to_csv('weekly_merged.csv', index=False)
print("\nSaved → weekly_merged.csv")
